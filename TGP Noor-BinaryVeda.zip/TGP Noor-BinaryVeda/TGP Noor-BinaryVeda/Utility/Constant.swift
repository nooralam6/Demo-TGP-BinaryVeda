//
//  Constant.swift
//  TGP Noor-BinaryVeda
//
//  Created by Nooralam Shaikh on 27/05/21.
//

import Foundation

struct TableViewReuseIdentifiers {
    static let infoCell = "infoCell"
}

struct CollectionViewReuseIdentifiers {
    static let imageCell = "imageCell"
}

struct UINibName {
    static let ImageCollectionViewCell = "ImageCollectionViewCell"
}
