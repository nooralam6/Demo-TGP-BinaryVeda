//
//  FontExtension.swift
//  TGP Noor-BinaryVeda
//
//  Created by Nooralam Shaikh on 27/05/21.
//

import UIKit

extension UIFont {
    class var lightHeadline: UIFont {
        return UIFont(name: "BarlowCondensed-ExtraLight", size: 32.0)!
    }
    class var lightTitle: UIFont {
        return UIFont(name: "BarlowCondensed-Light", size: 28.0)!
    }
    class var mediumTitle: UIFont {
        return UIFont(name: "BarlowCondensed-Medium", size: 16.0)!
    }
    class var subTitle: UIFont {
        return UIFont(name: "Barlow-ExtraLight", size: 18.0)!
    }
    class var lightSubtitle: UIFont {
        return UIFont(name: "Barlow-ExtraLight", size: 16.0)!
    }
    class var lightSmallBody: UIFont {
        return UIFont(name: "BarlowCondensed-Light", size: 14.0)!
    }
    class var lightHeadline2: UIFont {
        return UIFont(name: "BarlowCondensed-ExtraLight", size: 36.0)!
    }
    class var caption: UIFont {
        return UIFont(name: "BarlowCondensed-Light", size: 14)!
    }
}
