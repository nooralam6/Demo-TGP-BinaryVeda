//
//  ColorExtension.swift
//  TGP Noor-BinaryVeda
//
//  Created by Nooralam Shaikh on 27/05/21.
//

import UIKit

extension UIColor {
  @nonobjc class var tomato: UIColor {
    return UIColor(red: 236.0 / 255.0, green: 81.0 / 255.0, blue: 81.0 / 255.0, alpha: 1.0)
  }
    @nonobjc class var cornflowerBlue: UIColor {
        return UIColor(red: 89.0 / 255.0, green: 125.0 / 255.0, blue: 223.0 / 255.0, alpha: 1.0)
      }
}
