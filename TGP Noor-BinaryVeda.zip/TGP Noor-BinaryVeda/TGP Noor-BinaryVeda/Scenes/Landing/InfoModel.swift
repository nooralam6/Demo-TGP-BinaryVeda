//
//  InfoModel.swift
//  TGP Noor-BinaryVeda
//
//  Created by Nooralam Shaikh on 27/05/21.
//

import UIKit

struct InfoModel {
    let icon: UIImage
    let title, description: String
    
    static func getInfo() -> [InfoModel] {
        [
            InfoModel(icon: #imageLiteral(resourceName: "1"), title: "easy portfolio creation", description: "As a member you get easy to operate native app for clicking, editing and uploading your artwork. We have made this absolutely easy for your to not struggle with elaborate camera set ups."),
            InfoModel(icon: #imageLiteral(resourceName: "2"), title: "advanced data and analytics", description: "As an artist we are losing out on lot of insights about our art. We will be using data aboutt your audience to give you insights on various aspects so that you can plan your career smartly."),
            InfoModel(icon: #imageLiteral(resourceName: "3"), title: "reach authentic audience", description: "Since this platform is built on specific needs of a buyer we will be introducing some cutting edge tech to help buyers decide faster and more prudently. We also will be making suure your artt is protected by blockchain tech so that it becomes impossible to be copied."),
            InfoModel(icon: #imageLiteral(resourceName: "4"), title: "win awards at our flagship event", description: "TGP (The Gallry Prroject) will host awards to celebrate whats best around us. From young to established ones you will have opportunity to win awards in various cattegories. This would propel your profile and give your art journey a serious push"),
            InfoModel(icon: #imageLiteral(resourceName: "5"), title: "get published in our magazine", description: "TGP Magazine will be best in class magazine to showcase art. The aim is to publish artists on a regular basis and bring out the best talent from deep down regions around the world. This would ensure that online medium is exploited to its fullest with its unique property to reach Artists and buyers from anywhere - even Mars :)."),
            InfoModel(icon: #imageLiteral(resourceName: "6"), title: "stay updated with the art events", description: "Artists usually are busy in their work and get lost in their creativity. More than often they miss out on some wonderful events around. TGP will help bring this together on one platform where in all art events can be brought together and make surre you never miss out."),
            InfoModel(icon: #imageLiteral(resourceName: "7"), title: "author online exhibitions", description: "Physical showcasing has always been a challenge for artists. Right from boundaries of physical space to cost of hiring the galleries thten of coursee the logistical nightmares. TGP is creating probably the firs tof ts kind umlimited gallry space which can be hired and orchestrated on tthe click of a button.")
        ]
    }
}
