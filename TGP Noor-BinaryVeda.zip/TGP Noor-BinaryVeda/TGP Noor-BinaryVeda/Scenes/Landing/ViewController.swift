//
//  ViewController.swift
//  TGP Noor-BinaryVeda
//
//  Created by Nooralam Shaikh on 26/05/21.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var tableViewHeight: NSLayoutConstraint!
    
    let infoArray = InfoModel.getInfo()
    override func viewDidLoad() {
        super.viewDidLoad()
        setupTableView()
        self.navigationController?.setNavigationBarHidden(true, animated: false)
    }

    override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?) {
        tableViewHeight.constant = tableView.contentSize.height
    }

    deinit {
        tableView.removeObserver(self, forKeyPath: "contentSize")
    }
    
    func setupTableView() {
        tableView.addObserver(self, forKeyPath: "contentSize", options: .new, context: nil)
        tableView.reloadData()
    }
    
    @IBAction func registerButtonTapped(_ sender: UIButton) {
        self.navigationController?.pushViewController(ArtistProfileViewController(), animated: true) 
    }
}

extension ViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
       infoArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: TableViewReuseIdentifiers.infoCell, for: indexPath) as? InfoTableViewCell else {
            fatalError("InfoTableViewCell: deque failed")
        }
        cell.set(data: infoArray[indexPath.row])
        return cell
    }
    
    
}
