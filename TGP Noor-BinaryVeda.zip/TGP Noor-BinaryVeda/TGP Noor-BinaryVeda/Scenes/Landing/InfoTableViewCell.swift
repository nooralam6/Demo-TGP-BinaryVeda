//
//  InfoTableViewCell.swift
//  TGP Noor-BinaryVeda
//
//  Created by Nooralam Shaikh on 27/05/21.
//

import UIKit

class InfoTableViewCell: UITableViewCell {

    @IBOutlet weak var infoImageView: UIImageView!
    @IBOutlet weak var titleLabel: AppLabel!
    @IBOutlet weak var descriptionLabel: AppLabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

    func set(data: InfoModel) {
        infoImageView.image = data.icon
        titleLabel.text = data.title
        descriptionLabel.text = data.description
    }
}
