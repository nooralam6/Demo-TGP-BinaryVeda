//
//  ArtistProfileViewController.swift
//  TGP Noor-BinaryVeda
//
//  Created by Nooralam Shaikh on 27/05/21.
//

import UIKit

class ArtistProfileViewController: UIViewController {

    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var collectionViewHeight: NSLayoutConstraint!
    
    var images:[UIImage] = [#imageLiteral(resourceName: "gallery-5") , #imageLiteral(resourceName: "gallery-1"), #imageLiteral(resourceName: "gallery-2"), #imageLiteral(resourceName: "gallery-6"), #imageLiteral(resourceName: "gallery-4"), #imageLiteral(resourceName: "gallery-3")]
    
    init() {
        super.init(nibName: "ArtistProfileViewController", bundle: nil)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        setCollectionView()
    }

    func setCollectionView() {
        collectionView.register(UINib(nibName: UINibName.ImageCollectionViewCell, bundle: nil), forCellWithReuseIdentifier: CollectionViewReuseIdentifiers.imageCell)
        collectionView.addObserver(self, forKeyPath: "contentSize", options: .new, context: nil)
    }
    

    override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?) {
        collectionViewHeight.constant = collectionView.contentSize.height
    }
}

extension ArtistProfileViewController: UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        images.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: CollectionViewReuseIdentifiers.imageCell, for: indexPath) as? ImageCollectionViewCell else {
            fatalError("ImageCollectionViewCell: deque failed")
        }
        cell.imageView.image = images[indexPath.item]
        return cell
    }
}

extension ArtistProfileViewController: UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let size = (collectionView.frame.width / 2) - 5
        return CGSize(width: size, height: size)
    }
}
