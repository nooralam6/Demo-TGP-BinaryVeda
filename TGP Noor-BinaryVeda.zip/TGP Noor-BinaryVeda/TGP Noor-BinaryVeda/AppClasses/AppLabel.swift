//
//  AppLabel.swift
//  TGP Noor-BinaryVeda
//
//  Created by Nooralam Shaikh on 27/05/21.
//

import UIKit

enum LabelType: Int {
    case lightHeadline = 0
    case lightTitle
    case mediumTitle
    case lightSubtitle
    case lightSmallBody
}

@IBDesignable class AppLabel: UILabel {

    @IBInspectable
    public var labelType: Int = 0  {
        didSet {
            switch labelType {
            case 0: self.font = .lightHeadline
            case 1: self.font = .lightTitle
            case 2: self.font = .mediumTitle
            case 3: self.font = .lightSubtitle
            case 4: self.font = .lightSmallBody
            case 5: self.font = .lightHeadline2
            case 6: self.font = .caption
            case 7: self.font = .subTitle
            default: print("unhandled label type case")
            }
        }
    }

    @IBInspectable
    public var labelColor: Int = 0 {
        didSet {
            switch labelColor {
            case 0: self.textColor = .black
            case 1: self.textColor = .white
            case 2: self.textColor = .cornflowerBlue
            default: self.textColor = .black
            }
        }
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }

}
