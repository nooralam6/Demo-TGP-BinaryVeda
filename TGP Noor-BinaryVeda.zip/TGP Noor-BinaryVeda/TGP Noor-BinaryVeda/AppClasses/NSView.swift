//
//  NSView.swift
//  TGP Noor-BinaryVeda
//
//  Created by Nooralam Shaikh on 27/05/21.
//

import Foundation
import UIKit

@IBDesignable
class NSView: UIView {
    
    @IBInspectable var addCornerTopNotch: Bool = false {
        didSet {
            self.layoutSubviews()
        }
    }
    
}

class NSImageView: UIImageView {
    @IBInspectable var addCornerTopNotch: Bool = false {
        didSet {
            self.layoutSubviews()
        }
    }

}


@IBDesignable
class NSButton: UIButton {
    
    @IBInspectable var imageOnRight: Bool = false {
        didSet {
            self.semanticContentAttribute = UIApplication.shared
                .userInterfaceLayoutDirection == .rightToLeft ? .forceLeftToRight : .forceRightToLeft
        }
    }
    
    
    
    
    //    @IBInspectable var regularText: String = "" {
    //        didSet {
    //           setAttributedTitle()
    //        }
    //    }
    //
    //    @IBInspectable var regularColor: UIColor = .white {
    //        didSet {
    //            setAttributedTitle()
    //        }
    //    }
    //
    //    @IBInspectable var boldText: String = "" {
    //        didSet {
    //            setAttributedTitle()
    //        }
    //    }
    //
    //    @IBInspectable var boldColor: UIColor = .white {
    //        didSet {
    //           setAttributedTitle()
    //        }
    //    }
    
    //    func setAttributedTitle() {
    //        let text = NSMutableAttributedString()
    //        text.normal(regularText, textColor: regularColor).bold(" " + boldText , textColor: boldColor)
    //        self.setAttributedTitle(text, for: .normal)
    //    }
    
    //    func setNormalText(){
    //        let text = NSMutableAttributedString()
    //        text.normal(regularText, textColor: regularColor )
    //        self.setAttributedTitle(text, for: .normal)
    //    }
    
    @IBInspectable var setTitleLeftImageRight: Bool = false {
        didSet {
            if setTitleLeftImageRight {
                if let currentImageWidth = currentImage?.size.width, let width = self.titleLabel?.frame.size.width {
                    self.imageEdgeInsets = UIEdgeInsets(top: 0, left: self.frame.size.width - (currentImageWidth + 20) - width, bottom: 0, right: 0)
                    self.titleEdgeInsets = UIEdgeInsets(top: 0, left: 27, bottom: 0, right: currentImageWidth + 20)
                }
                
            }
        }
    }
    @IBInspectable var semiCircleButton: Int = 0 {
        didSet {
            switch semiCircleButton {
            case 1:
                setButtonSemi(isClockWise: true)
            case 2:
                setButtonSemi(isClockWise: false)
                
            default:
                print("nothing")
            }
        }
    }
    
    func setButtonSemi(isClockWise: Bool){
        if isClockWise {
            //            let circlePath = UIBezierPath(arcCenter: CGPoint(x: self.bounds.size.width / 2, y: 0), radius: self.bounds.size.height, startAngle: 0.0, endAngle: CGFloat.pi, clockwise: true)
            //            let circleShape = CAShapeLayer()
            //            circleShape.path = circlePath.cgPath
            //            self.layer.mask = circleShape
            //
            let circlePath = UIBezierPath.init(arcCenter: CGPoint(x: bounds.size.width / 2, y: 0), radius: bounds.size.height, startAngle: 0.0, endAngle: CGFloat.pi, clockwise: true)
            let circleShape = CAShapeLayer()
            circleShape.path = circlePath.cgPath
            layer.mask = circleShape
            
        } else {
            let arcCenter = CGPoint(x: bounds.size.width / 2, y: bounds.size.height / 2)
            let circleRadius = bounds.size.width / 2
            let circlePath = UIBezierPath(arcCenter: arcCenter, radius: circleRadius, startAngle: CGFloat.pi, endAngle: CGFloat.pi * 2, clockwise: true)
            let semiCirleLayer = CAShapeLayer()
            semiCirleLayer.path = circlePath.cgPath
            self.layer.mask = semiCirleLayer
            //            layer.addSublayer(semiCirleLayer)
        }
        
    }
}

@IBDesignable
class NSLabel: UILabel {
}
extension UIView {
    
    @IBInspectable
    var cornerRadius: CGFloat {
        get {
            return layer.cornerRadius
        }
        set {
            layer.cornerRadius = newValue
        }
    }
    
    @IBInspectable
    var borderWidth: CGFloat {
        get {
            return layer.borderWidth
        }
        set {
            layer.borderWidth = newValue
        }
    }
    
    @IBInspectable
    var borderColor: UIColor? {
        get {
            if let color = layer.borderColor {
                return UIColor(cgColor: color)
            }
            return nil
        }
        set {
            if let color = newValue {
                layer.borderColor = color.cgColor
            } else {
                layer.borderColor = nil
            }
        }
    }
    
    @IBInspectable
    var shadowRadius: CGFloat {
        get {
            return layer.shadowRadius
        }
        set {
            layer.shadowRadius = newValue
        }
    }
    
    @IBInspectable
    var shadowOpacity: Float {
        get {
            return layer.shadowOpacity
        }
        set {
            layer.shadowOpacity = newValue
        }
    }
    
    @IBInspectable
    var shadowOffset: CGSize {
        get {
            return layer.shadowOffset
        }
        set {
            layer.shadowOffset = newValue
        }
    }
    
    @IBInspectable
    var shadowColor: UIColor? {
        get {
            if let color = layer.shadowColor {
                return UIColor(cgColor: color)
            }
            return nil
        }
        set {
            if let color = newValue {
                layer.shadowColor = color.cgColor
            } else {
                layer.shadowColor = nil
            }
        }
    }
}

